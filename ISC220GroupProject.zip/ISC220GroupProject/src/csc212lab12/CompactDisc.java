/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csc212lab12;

/**
 *
 * @author mdaniels
 */
public class CompactDisc {

    private String UPC;
    private double price;
    private String artist;
    private String title;

    public CompactDisc(String u, double p, String a, String t) {
        UPC = u;
        price = p;
        artist = a;
        title = t;

    }

    public String getUPC() {
        return UPC;
    }

    public String toString() {
        return "Artist: " + artist + " Title: " + title + " Price: " + price;
    }
}
